INSTRUÇÕES — Publicar o simulador no GitHub Pages (link público)

Pré-requisito: ter uma conta no GitHub (gratuita).

1) Crie um repositório novo (ex.: laffer_v5).
2) Faça upload destes 2 arquivos para o repositório:
   - index.html   (é o simulador; copie/renomeie a partir de laffer_simulator_v5.html)
   - Manual_Simulador_Curva_de_Laffer_v5.0.pdf  (opcional para consulta)
3) Vá em Settings → Pages:
   - Build and deployment: Source = Deploy from a branch
   - Branch = main (ou master) / folder = /root → Save
4) O GitHub gerará um link do tipo:
   https://SEU_USUARIO.github.io/NOME_DO_REPO/
   (Ex.: https://professorronie.github.io/laffer_v5/)
5) Compartilhe este link no Google Classroom. Os alunos usam online sem baixar.

DICA: Para atualizar, basta subir uma nova versão do index.html no mesmo repositório.
